# Sharp Edge — Full Implementation Plan

> Sports betting analytics platform: pick accountability, parlay intelligence, live prediction.

---

## Table of Contents

1. [Tech Stack](#1-tech-stack)
2. [Monorepo Structure](#2-monorepo-structure)
3. [Environment Setup](#3-environment-setup)
4. [Database Schema](#4-database-schema)
5. [Phase 1 — Foundation](#5-phase-1--foundation-weeks-12)
6. [Phase 2 — Data Pipeline](#6-phase-2--data-pipeline-weeks-34)
7. [Phase 3 — Intelligence Engine](#7-phase-3--intelligence-engine-weeks-56)
8. [Phase 4 — User Platform](#8-phase-4--user-platform-weeks-78)
9. [Phase 5 — Monetization Layer](#9-phase-5--monetization-layer-weeks-910)
10. [Phase 6 — Production Hardening](#10-phase-6--production-hardening-weeks-1112)
11. [API Endpoint Reference](#11-api-endpoint-reference)
12. [Third-Party Integrations](#12-third-party-integrations)
13. [Deployment Checklist](#13-deployment-checklist)
14. [Cost Estimates](#14-cost-estimates)

---

## 1. Tech Stack

### Frontend
| Layer | Technology | Why |
|---|---|---|
| Web app | Next.js 14 (App Router) | SSR, SEO, API routes in one repo |
| Mobile | Expo (React Native) | iOS + Android from shared codebase |
| State | Zustand + React Query | Lightweight global state + server cache |
| Realtime UI | Socket.io client | Live odds and game updates |
| Charts | Recharts + D3 | Parlay probability and ROI curves |
| Auth | Clerk | Drop-in auth, handles JWT and sessions |
| Payments | Stripe.js | Subscriptions and pick package checkout |
| Styling | Tailwind CSS | Utility-first, consistent design system |

### Backend
| Layer | Technology | Why |
|---|---|---|
| Main API | Node.js + Fastify | Fast REST + WebSocket server |
| ML / Scoring | Python + FastAPI | Scoring engine and data pipeline |
| Job queue | BullMQ + Redis | Scheduled ingestion jobs |
| Real-time | Socket.io | Live game events push to clients |
| Auth middleware | Clerk SDK | Shared auth across services |
| API gateway | Kong (production) | Rate limiting, key management |

### Data
| Layer | Technology | Why |
|---|---|---|
| Primary DB | PostgreSQL (Supabase) | Relational data, Row Level Security |
| Time-series | TimescaleDB extension | Efficient odds history queries |
| Cache | Redis (Upstash) | Real-time odds, session data |
| Search | PostgreSQL full-text | Pick and seller search |
| Object storage | Cloudflare R2 | Exports, reports, assets |

### ML / Data Science
| Layer | Technology | Why |
|---|---|---|
| Models | scikit-learn + XGBoost | Confidence scoring, live prediction |
| NLP | Claude API | Sentiment analysis, pick extraction |
| Data transforms | dbt | Normalized stats pipeline |
| Orchestration | Temporal.io | Reliable scheduled workflows |
| Experiment tracking | MLflow | Model versioning and performance |

### Infrastructure
| Layer | Technology | Why |
|---|---|---|
| Frontend hosting | Vercel | Next.js native, global CDN |
| API hosting | Railway | Simple Node.js + Python services |
| Database | Supabase | Managed PostgreSQL + realtime |
| Redis | Upstash | Serverless Redis, pay-per-use |
| Monitoring | Sentry + PostHog | Error tracking + product analytics |
| Logs | Axiom | Structured log aggregation |
| CI/CD | GitHub Actions | Automated test + deploy |

---

## 2. Monorepo Structure

```
sharp-edge/
├── apps/
│   ├── web/                        # Next.js 14 web app
│   │   ├── app/
│   │   │   ├── (auth)/             # Login, signup pages
│   │   │   ├── (dashboard)/        # Main app layout
│   │   │   │   ├── page.tsx        # Dashboard / edge feed
│   │   │   │   ├── parlay/         # Parlay builder
│   │   │   │   ├── accountability/ # Pick tracker hub
│   │   │   │   ├── live/           # Live games tracker
│   │   │   │   └── account/        # User settings, billing
│   │   │   ├── api/                # Next.js API routes
│   │   │   │   ├── webhooks/       # Stripe, Clerk webhooks
│   │   │   │   └── trpc/           # tRPC handler (optional)
│   │   │   └── layout.tsx
│   │   ├── components/
│   │   │   ├── ui/                 # Shared UI primitives
│   │   │   ├── parlay/             # Parlay builder components
│   │   │   ├── accountability/     # Pick tracker components
│   │   │   └── charts/             # Recharts wrappers
│   │   ├── hooks/                  # Custom React hooks
│   │   ├── lib/                    # Client utilities
│   │   └── package.json
│   │
│   └── mobile/                     # Expo React Native app
│       ├── app/                    # Expo Router file-based nav
│       │   ├── (tabs)/
│       │   │   ├── index.tsx       # Dashboard
│   │       │   ├── parlay.tsx      # Parlay builder
│   │       │   ├── picks.tsx       # Accountability hub
│   │       │   └── live.tsx        # Live games
│       │   └── _layout.tsx
│       ├── components/
│       └── package.json
│
├── services/
│   ├── api/                        # Node.js + Fastify main API
│   │   ├── src/
│   │   │   ├── routes/
│   │   │   │   ├── sellers.ts      # Pick seller endpoints
│   │   │   │   ├── picks.ts        # Pick tracking endpoints
│   │   │   │   ├── odds.ts         # Odds feed endpoints
│   │   │   │   ├── parlays.ts      # Parlay calculator
│   │   │   │   ├── games.ts        # Game data endpoints
│   │   │   │   └── users.ts        # User endpoints
│   │   │   ├── websocket/
│   │   │   │   ├── live-games.ts   # Live score push
│   │   │   │   └── odds-stream.ts  # Real-time odds push
│   │   │   ├── middleware/
│   │   │   │   ├── auth.ts         # Clerk JWT verification
│   │   │   │   ├── rateLimit.ts    # Per-user rate limits
│   │   │   │   └── tier.ts         # Subscription tier gating
│   │   │   ├── db/
│   │   │   │   ├── client.ts       # Postgres client (Drizzle ORM)
│   │   │   │   └── schema.ts       # Drizzle schema
│   │   │   └── index.ts
│   │   └── package.json
│   │
│   ├── scoring/                    # Python FastAPI scoring engine
│   │   ├── app/
│   │   │   ├── main.py
│   │   │   ├── routers/
│   │   │   │   ├── confidence.py   # Confidence score endpoint
│   │   │   │   ├── parlay.py       # Parlay probability endpoint
│   │   │   │   └── live.py         # Live prediction endpoint
│   │   │   ├── models/
│   │   │   │   ├── player_trends.py
│   │   │   │   ├── sharp_money.py
│   │   │   │   ├── sentiment.py
│   │   │   │   └── live_predictor.py
│   │   │   ├── data/
│   │   │   │   ├── fetchers.py     # Pull from PostgreSQL
│   │   │   │   └── cache.py        # Redis caching layer
│   │   │   └── utils/
│   │   ├── requirements.txt
│   │   └── Dockerfile
│   │
│   ├── ingestion/                  # Python data pipeline
│   │   ├── pipelines/
│   │   │   ├── stats_pipeline.py   # SportsRadar → PostgreSQL
│   │   │   ├── odds_pipeline.py    # The Odds API → Redis + PG
│   │   │   ├── news_pipeline.py    # NewsAPI → sentiment scores
│   │   │   └── results_pipeline.py # Verify pick outcomes
│   │   ├── workflows/              # Temporal workflow definitions
│   │   │   ├── stats_workflow.py
│   │   │   ├── odds_workflow.py
│   │   │   └── verify_workflow.py
│   │   ├── requirements.txt
│   │   └── Dockerfile
│   │
│   └── social-scraper/             # Node.js social monitoring
│       ├── src/
│       │   ├── scrapers/
│       │   │   ├── twitter.ts      # X API scraper
│       │   │   ├── instagram.ts    # Instagram Graph API
│       │   │   └── tiktok.ts       # TikTok Research API
│       │   ├── extractors/
│       │   │   ├── pick-parser.ts  # NLP pick extraction
│       │   │   └── account-profiler.ts
│       │   ├── jobs/
│       │   │   ├── scan-job.ts     # BullMQ job definitions
│       │   │   └── verify-job.ts
│       │   └── index.ts
│       └── package.json
│
├── packages/
│   ├── shared/                     # Shared TypeScript types
│   │   ├── src/
│   │   │   ├── types/
│   │   │   │   ├── seller.ts
│   │   │   │   ├── pick.ts
│   │   │   │   ├── game.ts
│   │   │   │   ├── odds.ts
│   │   │   │   └── parlay.ts
│   │   │   └── index.ts
│   │   └── package.json
│   │
│   └── ui/                         # Shared React component library
│       ├── src/
│       │   ├── TierBadge.tsx
│       │   ├── ResultPill.tsx
│       │   ├── ConfidenceBar.tsx
│       │   ├── ROIChart.tsx
│       │   └── index.ts
│       └── package.json
│
├── infrastructure/
│   ├── docker-compose.yml          # Local dev environment
│   ├── docker-compose.prod.yml
│   └── .github/
│       └── workflows/
│           ├── ci.yml              # Test on PR
│           └── deploy.yml          # Deploy on merge to main
│
├── .env.example                    # All required env vars
├── turbo.json                      # Turborepo config
├── package.json                    # Root workspace config
└── README.md
```

---

## 3. Environment Setup

### Prerequisites
```bash
node >= 20.0.0
python >= 3.11
pnpm >= 9.0.0          # workspace package manager
docker + docker-compose # local services
```

### Initial Setup
```bash
# Clone and install
git clone https://github.com/your-org/sharp-edge
cd sharp-edge
pnpm install

# Copy env files
cp .env.example .env.local
cp services/api/.env.example services/api/.env
cp services/scoring/.env.example services/scoring/.env
cp services/ingestion/.env.example services/ingestion/.env

# Start local infrastructure (Postgres, Redis)
docker-compose up -d

# Run database migrations
pnpm db:migrate

# Seed development data
pnpm db:seed

# Start all services in development
pnpm dev
```

### Required Environment Variables

```bash
# ─── Database ───────────────────────────────────────
DATABASE_URL=postgresql://user:pass@localhost:5432/sharpedge
REDIS_URL=redis://localhost:6379

# ─── Auth (Clerk) ────────────────────────────────────
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...
CLERK_WEBHOOK_SECRET=whsec_...

# ─── Payments (Stripe) ───────────────────────────────
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_PRO=price_...
STRIPE_PRICE_SHARP=price_...

# ─── Sports Data ─────────────────────────────────────
SPORTSRADAR_API_KEY=...
ODDS_API_KEY=...            # The Odds API
MYSPORTSFEEDS_API_KEY=...
ESPN_API_KEY=...

# ─── Social Media ────────────────────────────────────
TWITTER_BEARER_TOKEN=...
TWITTER_API_KEY=...
TWITTER_API_SECRET=...
INSTAGRAM_ACCESS_TOKEN=...
TIKTOK_CLIENT_KEY=...
TIKTOK_CLIENT_SECRET=...

# ─── AI / NLP ────────────────────────────────────────
ANTHROPIC_API_KEY=sk-ant-...

# ─── News ────────────────────────────────────────────
NEWS_API_KEY=...

# ─── Affiliate ───────────────────────────────────────
DRAFTKINGS_AFFILIATE_ID=...
FANDUEL_AFFILIATE_ID=...
BETMGM_AFFILIATE_ID=...

# ─── Infrastructure ──────────────────────────────────
SENTRY_DSN=https://...
POSTHOG_KEY=phc_...
AXIOM_TOKEN=...
CLOUDFLARE_R2_BUCKET=...
CLOUDFLARE_R2_ACCESS_KEY=...
CLOUDFLARE_R2_SECRET_KEY=...
```

---

## 4. Database Schema

```sql
-- ─── Core entities ───────────────────────────────────────────────

CREATE TABLE players (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  universal_id  VARCHAR(64) UNIQUE NOT NULL,  -- cross-source key
  name          VARCHAR(255) NOT NULL,
  sport         VARCHAR(32) NOT NULL,
  team          VARCHAR(64),
  position      VARCHAR(32),
  status        VARCHAR(32) DEFAULT 'active', -- active | injured | out
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE games (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  external_id   VARCHAR(64) UNIQUE NOT NULL,
  sport         VARCHAR(32) NOT NULL,
  league        VARCHAR(32) NOT NULL,
  home_team     VARCHAR(64) NOT NULL,
  away_team     VARCHAR(64) NOT NULL,
  game_time     TIMESTAMPTZ NOT NULL,
  venue         VARCHAR(128),
  status        VARCHAR(32) DEFAULT 'scheduled', -- scheduled | live | final
  home_score    INT,
  away_score    INT,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Odds (TimescaleDB hypertable) ───────────────────────────────

CREATE TABLE odds_history (
  id            UUID DEFAULT gen_random_uuid(),
  game_id       UUID REFERENCES games(id),
  book          VARCHAR(64) NOT NULL,       -- draftkings | fanduel | pinnacle ...
  market        VARCHAR(64) NOT NULL,       -- spread | moneyline | total | prop
  label         VARCHAR(128),               -- "Chiefs -6.5" | "Over 48.5"
  price         INT NOT NULL,               -- American odds e.g. -110
  point         NUMERIC(5,1),               -- spread/total value
  is_opening    BOOLEAN DEFAULT FALSE,
  captured_at   TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (id, captured_at)
);
SELECT create_hypertable('odds_history', 'captured_at');

-- ─── Intelligence signals ────────────────────────────────────────

CREATE TABLE confidence_scores (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id         UUID REFERENCES games(id),
  market          VARCHAR(64) NOT NULL,
  label           VARCHAR(128) NOT NULL,
  score           NUMERIC(5,2) NOT NULL,    -- 0.00 to 100.00
  player_trend    NUMERIC(5,2),
  sharp_money     NUMERIC(5,2),
  sentiment       NUMERIC(5,2),
  schedule_edge   NUMERIC(5,2),
  pick_tracker    NUMERIC(5,2),
  model_version   VARCHAR(32),
  computed_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE sentiment_scores (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type     VARCHAR(32) NOT NULL,     -- player | team
  entity_id       UUID NOT NULL,
  score           NUMERIC(4,3),             -- -1.0 to 1.0
  injury_concern  NUMERIC(4,3),
  motivation      NUMERIC(4,3),
  source_count    INT,
  computed_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Pick tracker ────────────────────────────────────────────────

CREATE TABLE social_accounts (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  handle          VARCHAR(128) NOT NULL,
  platform        VARCHAR(32) NOT NULL,     -- twitter | instagram | tiktok
  profile_url     VARCHAR(512),
  followers       INT DEFAULT 0,
  tier            VARCHAR(32) DEFAULT 'unverified', -- elite|certified|verified|emerging|unverified
  trust_score     NUMERIC(5,2) DEFAULT 0,
  verified_w      INT DEFAULT 0,
  verified_l      INT DEFAULT 0,
  verified_roi    NUMERIC(7,2),
  claimed_roi     NUMERIC(7,2),             -- what they claim publicly
  is_fraud        BOOLEAN DEFAULT FALSE,
  tracking_since  TIMESTAMPTZ DEFAULT NOW(),
  last_active     TIMESTAMPTZ,
  UNIQUE(handle, platform)
);

CREATE TABLE tracked_picks (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id      UUID REFERENCES social_accounts(id),
  game_id         UUID REFERENCES games(id),
  post_url        VARCHAR(512),
  post_content    TEXT,
  sport           VARCHAR(32),
  bet_type        VARCHAR(64),              -- spread | ml | total | prop | parlay
  bet_label       VARCHAR(256),             -- "Chiefs -6.5"
  odds_at_post    INT,                      -- American odds when posted
  closing_odds    INT,                      -- odds at game time (for CLV calc)
  posted_at       TIMESTAMPTZ NOT NULL,     -- IMMUTABLE timestamp
  result          VARCHAR(16),             -- win | loss | push | pending
  units_returned  NUMERIC(6,3),
  clv             NUMERIC(6,3),             -- closing line value
  verified_at     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast leaderboard queries
CREATE INDEX idx_tracked_picks_account ON tracked_picks(account_id, posted_at DESC);
CREATE INDEX idx_tracked_picks_pending ON tracked_picks(result) WHERE result = 'pending';

-- ─── Users and subscriptions ─────────────────────────────────────

CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  clerk_id        VARCHAR(128) UNIQUE NOT NULL,
  email           VARCHAR(255) UNIQUE NOT NULL,
  username        VARCHAR(64) UNIQUE,
  tier            VARCHAR(32) DEFAULT 'free',  -- free | pro | sharp
  stripe_id       VARCHAR(128),
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE user_parlays (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID REFERENCES users(id),
  legs            JSONB NOT NULL,           -- array of bet leg objects
  combined_prob   NUMERIC(5,2),             -- our adjusted probability
  book_implied    NUMERIC(5,2),             -- book's implied probability
  edge_score      NUMERIC(5,2),             -- positive = we have the edge
  payout_odds     INT,                      -- American odds for full parlay
  status          VARCHAR(32) DEFAULT 'saved', -- saved | placed | won | lost
  sportsbook      VARCHAR(64),              -- where they placed it
  placed_at       TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Affiliate tracking ──────────────────────────────────────────

CREATE TABLE affiliate_clicks (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID REFERENCES users(id),
  sportsbook      VARCHAR(64) NOT NULL,
  parlay_id       UUID REFERENCES user_parlays(id),
  clicked_at      TIMESTAMPTZ DEFAULT NOW(),
  converted       BOOLEAN DEFAULT FALSE,
  conversion_at   TIMESTAMPTZ
);
```

---

## 5. Phase 1 — Foundation (Weeks 1–2)

**Goal:** Monorepo running locally, auth, database, and skeleton of all services.

### Tasks

**Repo setup**
- [ ] Init Turborepo workspace with pnpm
- [ ] Configure shared TypeScript config (`tsconfig.base.json`)
- [ ] Set up ESLint + Prettier across all packages
- [ ] Configure GitHub Actions CI (lint + type-check on PR)
- [ ] Set up `.env.example` with all required variables

**Database**
- [ ] Provision Supabase project (dev + prod)
- [ ] Enable TimescaleDB extension
- [ ] Write all migrations using Drizzle ORM
- [ ] Configure Row Level Security policies on user tables
- [ ] Write seed script with 20 mock games, 50 players, 8 sellers

**Auth**
- [ ] Integrate Clerk into Next.js app
- [ ] Build `middleware.ts` protecting all `/dashboard` routes
- [ ] Sync Clerk user to `users` table via webhook
- [ ] Add auth middleware to Fastify API (`clerk-sdk-node`)

**API service scaffold**
- [ ] Fastify server with plugin architecture
- [ ] Drizzle ORM connected to PostgreSQL
- [ ] Redis client (Upstash) connected
- [ ] Health check endpoint (`GET /health`)
- [ ] Error handling + structured logging (Axiom)

**Frontend scaffold**
- [ ] Next.js 14 app with Tailwind + Clerk
- [ ] Dashboard layout with sidebar nav
- [ ] Mobile Expo app scaffold with Expo Router

### Key Files to Write First

```typescript
// services/api/src/db/schema.ts — single source of truth for DB shape
// services/api/src/middleware/auth.ts — protects all routes
// apps/web/app/layout.tsx — ClerkProvider wrapping entire app
// turbo.json — defines build pipeline dependencies
```

---

## 6. Phase 2 — Data Pipeline (Weeks 3–4)

**Goal:** Real odds, stats, and social picks flowing into the database automatically.

### Tasks

**Odds pipeline**
- [ ] The Odds API client with retry logic
- [ ] Fetch all games + odds for NFL, NBA, MLB, NHL on startup
- [ ] Diff engine: only write to DB when line moves >0.5 points
- [ ] Store every captured odds record in `odds_history` (TimescaleDB)
- [ ] Cache current odds in Redis with 5-min TTL
- [ ] BullMQ job: refresh odds every 3 minutes during live games

```python
# services/ingestion/pipelines/odds_pipeline.py
async def fetch_and_store_odds():
    raw = await odds_api_client.get_odds(sports=ACTIVE_SPORTS)
    for game in raw:
        current = await redis.get(f"odds:{game.id}")
        if has_significant_movement(current, game.odds):
            await db.insert_odds_history(game)
            await redis.setex(f"odds:{game.id}", 300, game.odds)
            await notify_subscribers(game.id, game.odds)
```

**Stats pipeline**
- [ ] SportsRadar client (player game logs, rosters, injuries)
- [ ] Universal player ID mapping table across all data sources
- [ ] Nightly job: pull all player stats for past 24 hours
- [ ] Injury feed: webhook listener for immediate updates
- [ ] dbt models: rolling 10-game averages per player

**Social scraper**
- [ ] Twitter/X API v2 client — search for betting hashtags + account monitoring
- [ ] Pick extraction prompt (Claude API):

```typescript
// services/social-scraper/src/extractors/pick-parser.ts
const EXTRACT_PROMPT = `
Extract betting pick information from this social media post.
Return JSON only:
{
  "has_pick": boolean,
  "sport": string | null,
  "game": string | null,
  "bet_type": "spread"|"moneyline"|"total"|"prop"|"parlay"|null,
  "bet_label": string | null,
  "odds": number | null,
  "confidence": "lock"|"lean"|"play"|null
}
Post: {{POST_CONTENT}}
`;
```

- [ ] Immutable timestamp lock: write `posted_at` immediately, never update
- [ ] BullMQ job: scan monitored accounts every 30 minutes
- [ ] Result verification job: runs nightly, checks all `pending` picks against scores

**News pipeline**
- [ ] NewsAPI client filtering sports content
- [ ] Claude API sentiment scoring per player/team mentioned
- [ ] Store scores in `sentiment_scores` with entity linking
- [ ] Breaking news webhook (Rotowire) for injury alerts

---

## 7. Phase 3 — Intelligence Engine (Weeks 5–6)

**Goal:** Confidence scores calculating for all active bet markets.

### Scoring Architecture

```python
# services/scoring/app/models/confidence.py

WEIGHTS = {
    "player_trend":   0.25,
    "sharp_money":    0.20,
    "sentiment":      0.15,
    "schedule_edge":  0.15,
    "pick_tracker":   0.10,
    "matchup":        0.15,
}

def compute_confidence(game_id: str, market: str, label: str) -> ConfidenceScore:
    signals = {
        "player_trend":   PlayerTrendModel().score(game_id, label),
        "sharp_money":    SharpMoneyModel().score(game_id, market),
        "sentiment":      SentimentModel().score(game_id, label),
        "schedule_edge":  ScheduleModel().score(game_id),
        "pick_tracker":   PickTrackerModel().score(game_id, label),
        "matchup":        MatchupModel().score(game_id, label),
    }
    weighted = sum(signals[k] * WEIGHTS[k] for k in signals)
    return ConfidenceScore(score=weighted, signals=signals)
```

### Tasks

**Player trend model**
- [ ] 10-game rolling average vs season average (weighted recency)
- [ ] Matchup grade: target player vs opposing defense rating
- [ ] Home/away splits, rest days (>3 days = +score)
- [ ] Usage rate trend (for props specifically)
- [ ] Output: 0–100 signal score

**Sharp money detector**
- [ ] Compare public betting % (from The Odds API) vs line movement
- [ ] Flag reverse line movement: line moves opposite to public money
- [ ] Steam move detection: rapid multi-book movement within 60s
- [ ] CLV calculator: compare pick odds to closing line
- [ ] Output: -50 to +50 signal (-50 = heavy public fade, +50 = sharp action)

**Parlay probability engine**
```python
# services/scoring/app/routers/parlay.py

def compute_parlay_probability(legs: list[ParlayLeg]) -> ParlayResult:
    # Convert each leg's confidence score to an adjusted probability
    adjusted_probs = []
    for leg in legs:
        raw_implied = american_to_implied(leg.odds)
        confidence = get_confidence_score(leg.game_id, leg.market, leg.label)
        adjustment = (confidence.score - 50) * 0.003  # ±15% max adjustment
        adjusted_prob = max(0.05, min(0.95, raw_implied + adjustment))
        adjusted_probs.append(adjusted_prob)
    
    # Handle correlation between same-game legs (SGP)
    correlation_factor = compute_correlation(legs)
    
    # Combined parlay probability
    combined = 1.0
    for p in adjusted_probs:
        combined *= p
    combined *= correlation_factor
    
    book_implied = 1.0
    for leg in legs:
        book_implied *= american_to_implied(leg.odds)
    
    return ParlayResult(
        adjusted_probability=combined,
        book_implied_probability=book_implied,
        edge=combined - book_implied,
        legs=zip(legs, adjusted_probs)
    )
```

**Pick tracker trust scoring**
- [ ] Minimum 30 picks before trust score assigned
- [ ] ROI calculation: `((units_won - units_lost) / total_units_wagered) * 100`
- [ ] CLV-based scoring: good bettors beat the closing line consistently
- [ ] Tier assignment thresholds:

```python
def assign_tier(account: SocialAccount) -> str:
    picks = account.verified_picks
    if len(picks) < 30: return "unverified"
    roi = account.verified_roi
    win_pct = account.verified_w / len(picks)
    months_tracked = account.months_active
    
    if months_tracked >= 12 and roi > 15 and win_pct > 0.58: return "elite"
    if months_tracked >= 6  and roi > 8  and win_pct > 0.55: return "certified"
    if months_tracked >= 3  and roi > 3  and win_pct > 0.53: return "verified"
    return "emerging"
```

**Fraud detection**
- [ ] Flag if claimed ROI > verified ROI by more than 20 points
- [ ] Pattern detection: accounts that never post losses publicly
- [ ] Cherry-picking detection: compare public picks vs DMs picks timing

---

## 8. Phase 4 — User Platform (Weeks 7–8)

**Goal:** Full working web app — dashboard, parlay builder, accountability hub, live games.

### Dashboard (Edge Feed)

```typescript
// apps/web/app/(dashboard)/page.tsx

// Server component — fetch today's top confidence scores
async function DashboardPage() {
  const edges = await getTopEdges({ minScore: 65, limit: 20 });
  const sharpMoves = await getRecentSharpMoves({ hours: 6 });
  return (
    <>
      <EdgeFeed edges={edges} />
      <SharpMoveAlert moves={sharpMoves} />
    </>
  );
}
```

Key components to build:
- [ ] `EdgeCard` — single bet edge with confidence bar, sharp indicator, add-to-parlay button
- [ ] `SharpMoveAlert` — real-time banner when a major line move fires
- [ ] `TodayPerformance` — platform's live pick record for today
- [ ] `QuickParlay` — drag-and-drop legs from edge feed into parlay builder

### Parlay Builder

Key components:
- [ ] `ParlayLegList` — ordered list of added legs with individual probabilities
- [ ] `ProbabilityMeter` — visual gauge comparing your probability vs book implied
- [ ] `EdgeIndicator` — green/red indicator showing if parlay has positive EV
- [ ] `BookDeepLink` — "Bet This Now" button with affiliate deep-link routing
- [ ] `ParlayShare` — generate shareable slip image (Canvas API)

```typescript
// hooks/useParlay.ts — core parlay state management
function useParlay() {
  const [legs, setLegs] = useState<ParlayLeg[]>([]);
  
  const probability = useQuery({
    queryKey: ["parlay-probability", legs],
    queryFn: () => api.post("/parlays/probability", { legs }),
    enabled: legs.length > 0,
    refetchInterval: 30_000, // refresh as odds move
  });
  
  return { legs, addLeg, removeLeg, probability };
}
```

### Accountability Hub

Key components (extend the prototype already built):
- [ ] Connect to real `social_accounts` + `tracked_picks` tables
- [ ] `SellerSearch` with debounced query
- [ ] `FraudAlertBanner` with share-to-Twitter functionality
- [ ] `PickTimeline` — chronological view with result overlays
- [ ] `TrustBadge` API: `GET /api/sellers/:handle/badge` (embeddable)

### Live Games

- [ ] WebSocket connection to `live-games` namespace
- [ ] `LiveParlaySidebar` — active slip with leg statuses updating in real time
- [ ] `MomentumFeed` — play-by-play events affecting bet outcomes
- [ ] `WinProbabilityGauge` — live model output per leg

```typescript
// Real-time connection
const socket = io(process.env.API_URL, {
  auth: { token: await getToken() }
});

socket.on("odds:update", (data) => updateOddsInStore(data));
socket.on("game:score", (data) => updateGameScore(data));
socket.on("parlay:probability", (data) => updateLiveProbability(data));
```

---

## 9. Phase 5 — Monetization Layer (Weeks 9–10)

**Goal:** Subscriptions, affiliate routing, and pick package marketplace live.

### Subscription Tiers

| Feature | Free | Pro ($19/mo) | Sharp ($49/mo) |
|---|---|---|---|
| Edge feed | 3/day | Unlimited | Unlimited |
| Confidence scores | Hidden | Full | Full |
| Parlay builder | 2 legs | Unlimited | Unlimited |
| Pick tracker | View only | Full access | Full access |
| Sharp money alerts | — | — | Real-time |
| Live game model | — | — | Full |
| API access | — | — | 1,000 calls/mo |

**Stripe setup:**
- [ ] Create Pro and Sharp subscription products in Stripe dashboard
- [ ] Implement `POST /api/subscriptions/create` endpoint
- [ ] Stripe webhook handler: sync subscription status to `users.tier`
- [ ] Feature gate middleware using `users.tier` from DB

```typescript
// services/api/src/middleware/tier.ts
export function requireTier(minTier: 'pro' | 'sharp') {
  return async (request, reply) => {
    const user = await db.query.users.findFirst({
      where: eq(users.clerkId, request.auth.userId)
    });
    const tiers = ['free', 'pro', 'sharp'];
    if (tiers.indexOf(user.tier) < tiers.indexOf(minTier)) {
      return reply.status(403).send({ error: 'upgrade_required', tier: minTier });
    }
  };
}
```

### Affiliate Deep-Links

```typescript
// apps/web/lib/affiliate.ts
const BOOKS = {
  draftkings: {
    baseUrl: "https://sportsbook.draftkings.com/",
    affiliateParam: `?wpcid=...&wpcn=...`,
  },
  fanduel: {
    baseUrl: "https://www.fanduel.com/sportsbook",
    affiliateParam: `?pid=...`,
  },
};

export function buildDeepLink(book: string, parlay: ParlayLeg[]) {
  // Build pre-filled bet slip URL using book's query params
  // Log click to affiliate_clicks table
}
```

### Pick Package Marketplace

- [ ] `SellerDashboard` — for Elite/Certified sellers to create packages
- [ ] Package types: daily ($5), weekly ($20), monthly ($49)
- [ ] Stripe Connect for seller payouts (platform takes 25%)
- [ ] Automatic performance disclosure on every package listing
- [ ] Gating: only `certified` or `elite` tier sellers can list

---

## 10. Phase 6 — Production Hardening (Weeks 11–12)

**Goal:** Secure, monitored, scalable, and compliant for real users.

### Security
- [ ] Enable Supabase Row Level Security on all user tables
- [ ] API rate limiting: 100 req/min free, 1000 req/min pro, 5000 req/min sharp
- [ ] Input validation on all endpoints (Zod schemas)
- [ ] SQL injection prevention (Drizzle ORM parameterized queries)
- [ ] CORS configuration for production domains only
- [ ] Secrets rotation procedure documented

### Legal & Compliance
- [ ] Terms of Service covering analytics-only nature of the platform
- [ ] Privacy Policy compliant with CCPA + GDPR
- [ ] "For entertainment purposes" disclaimers on all pick content
- [ ] Age gate on signup (21+) with state-level geo-restrictions where required
- [ ] Review upstream data licenses before any B2B API launch
- [ ] Consult gambling attorney before production launch

### Monitoring
- [ ] Sentry error tracking in all services
- [ ] PostHog product analytics (funnel tracking: view → parlay → click affiliate)
- [ ] Uptime monitoring (Better Uptime) with PagerDuty alerts
- [ ] Database query performance monitoring (pg_stat_statements)
- [ ] Redis memory usage alerts

### Performance
- [ ] Next.js page caching strategy (ISR for edge feed, static for seller profiles)
- [ ] PostgreSQL indexes verified with `EXPLAIN ANALYZE`
- [ ] Redis caching for all confidence scores (5-min TTL)
- [ ] CDN caching for static assets (Cloudflare)
- [ ] Load test with k6 before launch (target: 1000 concurrent users)

---

## 11. API Endpoint Reference

```
# Games & Odds
GET  /api/games                    → upcoming + live games
GET  /api/games/:id                → single game with odds
GET  /api/games/:id/odds-history   → line movement history
GET  /api/odds/top-movements       → biggest moves last 6h

# Confidence Scoring (Pro+ only)
GET  /api/scores/:gameId/:market   → confidence score for one market
GET  /api/scores/top-edges         → today's top confidence scores

# Parlay Builder
POST /api/parlays/probability      → compute adjusted probability
POST /api/parlays                  → save parlay to user account
GET  /api/parlays                  → user's saved parlays
GET  /api/parlays/:id/live         → live probability for active parlay

# Accountability Hub
GET  /api/sellers                  → leaderboard (filterable, sortable)
GET  /api/sellers/:handle          → seller profile + stats
GET  /api/sellers/:handle/picks    → verified pick history (paginated)
GET  /api/sellers/:handle/badge    → embeddable trust badge
GET  /api/sellers/fraud-alerts     → recently exposed accounts

# Users
GET  /api/users/me                 → current user profile + tier
POST /api/subscriptions/create     → create Stripe subscription
POST /api/subscriptions/cancel     → cancel subscription
GET  /api/users/me/parlays         → user's parlay history

# Affiliate
POST /api/affiliate/click          → log affiliate click + get deep-link

# WebSocket events
ws: odds:update                    → real-time odds movement
ws: game:score                     → score update
ws: sharp:alert                    → sharp money move detected
ws: parlay:probability             → live probability for active slip
```

---

## 12. Third-Party Integrations

| Service | Purpose | Estimated Cost | Sign-up |
|---|---|---|---|
| SportsRadar | Player stats, schedules, live scores | $500–$2,000/mo | sportsradar.com/marketplace |
| The Odds API | Odds across 40+ books | $0–$150/mo | the-odds-api.com |
| Anthropic (Claude) | Sentiment analysis, pick extraction | ~$50–$300/mo | console.anthropic.com |
| NewsAPI | Sports news feed | $0–$449/mo | newsapi.org |
| Twitter/X API | Social pick monitoring | $100/mo (Basic) | developer.x.com |
| Instagram Graph API | Public post monitoring | Free (rate limited) | developers.facebook.com |
| Clerk | Auth | $0–$25/mo | clerk.com |
| Supabase | PostgreSQL + realtime | $0–$25/mo | supabase.com |
| Upstash | Redis | $0–$30/mo | upstash.com |
| Stripe | Payments | 2.9% + 30¢/txn | stripe.com |
| Vercel | Frontend hosting | $0–$20/mo | vercel.com |
| Railway | API + Python hosting | $20–$100/mo | railway.app |
| Sentry | Error monitoring | $0–$26/mo | sentry.io |

**Total estimated dev/early-stage cost: $800–$3,200/month**
The dominant cost is SportsRadar. Start with their trial tier and The Odds API free plan — sufficient to build and demo the full product.

---

## 13. Deployment Checklist

### Before First Deploy
- [ ] All environment variables set in Vercel + Railway dashboards
- [ ] Database migrations run on production Supabase
- [ ] Stripe webhooks registered for production URL
- [ ] Clerk webhooks registered for production URL
- [ ] CORS configured to allow only production domains
- [ ] Sentry DSN configured in all services
- [ ] Rate limiting configured in Kong / Fastify

### Deploy Order
1. Database migrations (`pnpm db:migrate --env production`)
2. API service (`railway up --service api`)
3. Scoring service (`railway up --service scoring`)
4. Ingestion service (`railway up --service ingestion`)
5. Social scraper (`railway up --service social-scraper`)
6. Web app (`vercel --prod`)
7. Smoke test all endpoints
8. Enable BullMQ jobs (ingestion starts running)
9. Monitor Sentry + logs for first 30 minutes

### CI/CD Pipeline

```yaml
# .github/workflows/deploy.yml
name: Deploy
on:
  push:
    branches: [main]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v3
      - run: pnpm install
      - run: pnpm lint
      - run: pnpm typecheck
      - run: pnpm test
  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - run: vercel deploy --prod --token=${{ secrets.VERCEL_TOKEN }}
      - run: railway up --service api --token=${{ secrets.RAILWAY_TOKEN }}
```

---

## 14. Cost Estimates

### MVP (0–1,000 users)
| Item | Monthly Cost |
|---|---|
| SportsRadar (trial/basic) | $0–$500 |
| The Odds API (starter) | $0 |
| Claude API | ~$30 |
| Infrastructure (Vercel + Railway + Supabase) | $45 |
| Clerk + Stripe | $0 (usage-based) |
| **Total** | **~$75–$575/mo** |

### Growth (1,000–10,000 users)
| Item | Monthly Cost |
|---|---|
| SportsRadar (standard) | $1,000–$2,000 |
| The Odds API (pro) | $80 |
| Claude API | ~$200 |
| Infrastructure | $200 |
| Social media APIs | $100 |
| **Total** | **~$1,600–$2,600/mo** |

### Revenue to cover costs at Growth tier:
- 80 Pro subscribers ($19/mo) = $1,520 → break even at standard infra
- 10 Sharp subscribers ($49/mo) = $490 → significantly offsets data costs
- Affiliate revenue typically exceeds subscription revenue at 5,000+ MAU

---

## Quick Reference: Build Order

```
Week 1–2:  Monorepo → Auth → Database migrations → API scaffold
Week 3–4:  Odds pipeline → Stats pipeline → Social scraper → Result verification
Week 5–6:  Confidence scoring → Parlay engine → Fraud detection → Trust tiers
Week 7–8:  Dashboard → Parlay builder → Accountability hub → Live games
Week 9–10: Stripe subscriptions → Affiliate deep-links → Pick marketplace
Week 11–12: Security audit → Legal review → Load testing → Production deploy
```

**Start here on day 1:**
```bash
mkdir sharp-edge && cd sharp-edge
pnpm dlx create-turbo@latest .
```

Then follow Phase 1 tasks in order. Everything else builds on that foundation.
